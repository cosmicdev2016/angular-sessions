import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  //need tp be initialized
  items: { name: string, price: string, desc: string } [] = [];

  constructor() {
    this.items.push({name:'Mobiles', price: '10,000', desc: 'Mobile description'});
  }

  updateItems(itemAdded :{ name: string, price: string, desc: string }) {
    this.items.push(itemAdded);
  }

  removeItem(cardId) {
    console.log("in root component... ", cardId);
    this.items.splice(cardId, 1);
  }
}
